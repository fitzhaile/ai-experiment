// Eugene the AI Sea Cow - Chat Interface JavaScript

const btn = document.getElementById('btn');
const promptEl = document.getElementById('prompt');
const logEl = document.getElementById('log');
const statusEl = document.getElementById('status');
const govOnlyCheckbox = document.getElementById('govOnly');
const messages = [
  { role: 'system', content: 'You are a concise assistant that writes clear answers.' }
];

function render() {
  logEl.innerHTML = '';
  for (const m of messages) {
    if (m.role === 'system') continue;
    const div = document.createElement('div');
    div.className = 'msg ' + (m.role === 'user' ? 'user' : 'assistant');
    if (m.role === 'assistant') {
      // Convert markdown to HTML
      div.innerHTML = renderMarkdown(m.content);
    } else {
      // Remove the .gov filter instruction from display
      let displayContent = m.content;
      displayContent = displayContent.replace(/\s*\(Only cite sources from \.gov domains\)\s*$/, '');
      div.textContent = displayContent;
    }
    logEl.appendChild(div);
  }
  logEl.scrollTop = logEl.scrollHeight;
}

function renderMarkdown(text) {
  let html = text;
  
  // Escape HTML first
  html = html.replace(/&/g, '&amp;')
             .replace(/</g, '&lt;')
             .replace(/>/g, '&gt;');
  
  // Bold **text**
  html = html.replace(/\*\*([^\*]+)\*\*/g, '<strong>$1</strong>');
  
  // Italic *text* (but not if it's part of **)
  html = html.replace(/(?<!\*)\*([^\*]+)\*(?!\*)/g, '<em>$1</em>');
  
  // Links [text](url)
  html = html.replace(/\[([^\]]+)\]\((https?:\/\/[^\)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
  
  // Inline code `code`
  html = html.replace(/`([^`]+)`/g, '<code>$1</code>');
  
  // Headings
  html = html.replace(/^### (.+)$/gm, '<h3>$1</h3>');
  html = html.replace(/^## (.+)$/gm, '<h2>$1</h2>');
  html = html.replace(/^# (.+)$/gm, '<h1>$1</h1>');
  
  // Line breaks
  html = html.replace(/\n/g, '<br>');
  
  return html;
}

async function send() {
  const content = promptEl.value.trim() || 'Say hello.';
  const govOnly = govOnlyCheckbox.checked;
  
  // Add .gov filter instruction to user message if checkbox is checked
  let userContent = content;
  if (govOnly) {
    userContent = content + ' (Only cite sources from .gov domains)';
  }
  
  messages.push({ role: 'user', content: userContent });
  promptEl.value = '';
  render();

  try {
    // show loading state
    statusEl.textContent = 'Looking for your answers…';
    btn.disabled = true;
    promptEl.disabled = true;
    
    const res = await fetch('/api/chat?web=1', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages })
    });
    const data = await res.json();
    
    if (data && data.text) {
      messages.push({ role: 'assistant', content: data.text });
    } else if (data && data.error) {
      messages.push({ role: 'assistant', content: 'Error: ' + data.error });
    } else {
      messages.push({ role: 'assistant', content: '(no response)' });
    }
  } catch (e) {
    messages.push({ role: 'assistant', content: 'Error: ' + e });
  }
  
  render();
  // clear loading state
  statusEl.textContent = '';
  btn.disabled = false;
  promptEl.disabled = false;
  promptEl.focus();
}

btn.addEventListener('click', send);
promptEl.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    e.preventDefault();
    send();
  }
});

// Initial render
render();
