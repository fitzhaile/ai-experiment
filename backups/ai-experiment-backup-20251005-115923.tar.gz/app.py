"""
Flask app: Eugene the AI Sea Cow chat interface.

Endpoints:
- GET  /           → Chat UI with web search capability
- POST /api/chat   → Multi-turn chat API with optional web search (?web=1)

Environment variables:
- OPENAI_API_KEY (required): your OpenAI API key
- PORT (optional): server port (default 5000)
- FLASK_DEBUG (optional): set to "1" for auto-reload and debug mode
"""

from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request
from openai import OpenAI
from flask_cors import CORS
import logging
import os
from pathlib import Path

# Load .env from the app directory
dotenv_path = Path(__file__).resolve().parent / ".env"
load_dotenv(dotenv_path=dotenv_path, override=True)

# Configure logging
logging.basicConfig(level=logging.INFO)
if os.getenv("OPENAI_API_KEY"):
    logging.info("OPENAI_API_KEY detected: %s***", (os.getenv("OPENAI_API_KEY") or "")[:7])
else:
    logging.warning("OPENAI_API_KEY not set")

# Initialize Flask app
app = Flask(__name__)
CORS(app)

# Initialize OpenAI client (reused across requests)
openai_client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
MODEL = "gpt-4o-mini"


@app.get("/")
def index():
    """Render the chat UI."""
    return render_template("index.html")


@app.post("/api/chat")
def api_chat():
    """
    Multi-turn chat endpoint.
    Expects JSON: { "messages": [{"role":"user|assistant|system","content":"..."}, ...] }
    Returns: { "text": "assistant reply" }
    """
    try:
        if not os.getenv("OPENAI_API_KEY"):
            return jsonify({"error": "OPENAI_API_KEY not set"}), 500

        data = request.get_json(silent=True) or {}
        messages = data.get("messages")
        if not isinstance(messages, list) or not messages:
            return jsonify({"error": "messages[] required"}), 400

        # Enable web search when requested via query parameter
        use_web = request.args.get("web") == "1"
        if use_web:
            try:
                # Build conversation context from all messages
                conversation_parts = [
                    f"{m.get('role', '').capitalize()}: {m.get('content', '')}"
                    for m in messages
                    if isinstance(m, dict) and m.get("role") in ("system", "user", "assistant")
                ]
                full_context = "\n\n".join(conversation_parts)
                
                # Use Responses API with web_search tool
                resp = openai_client.responses.create(
                    model=MODEL,
                    input=full_context,
                    tools=[{"type": "web_search"}],
                    tool_choice="auto",
                    store=False,
                )
                text = (resp.output_text or "").strip()
                if text:
                    return jsonify({"text": text, "web": True})
            except Exception as web_err:
                logging.warning("Web search failed, falling back to chat.completions: %s", web_err)

        # Standard chat completion (no web search)
        chat = openai_client.chat.completions.create(model=MODEL, messages=messages)
        text = (chat.choices[0].message.content or "").strip()
        return jsonify({"text": text})
    except Exception as e:
        logging.exception("/api/chat error")
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    # Allow overriding the port via `PORT` env var (default 5000)
    port = int(os.getenv("PORT", "5000"))
    # `FLASK_DEBUG=1` enables auto-reload + debugger (local dev only)
    debug = os.getenv("FLASK_DEBUG", "0") == "1"
    app.run(host="0.0.0.0", port=port, debug=debug)


