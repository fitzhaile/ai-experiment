"""
Flask app: serves a tiny UI at `/` and an API at `/api/haiku`.

How it works (high level):
- Loads environment variables from `.env` (via python-dotenv) so you don't
  have to export them manually in your shell.

- Initializes a Flask app and enables CORS so the static page can call the API.

- GET `/` returns a minimal HTML page with a text box and button.

- GET `/api/haiku` calls OpenAI with your prompt and returns JSON `{text: ...}`.

Key environment variables:
- OPENAI_API_KEY (required): your real API key.
- PORT (optional): which port Flask should bind to when running `python app.py`.
- FLASK_DEBUG (optional): `1` enables auto-reload and debug logging.
"""

from dotenv import load_dotenv
from flask import Flask, jsonify, render_template_string, request
from openai import OpenAI
from flask_cors import CORS
import httpx
import logging
import os

from pathlib import Path
# Load `.env` from the app directory so starting the app from any cwd still works
dotenv_path = Path(__file__).resolve().parent / ".env"
load_dotenv(dotenv_path=dotenv_path, override=True)
logging.basicConfig(level=logging.INFO)
if os.getenv("OPENAI_API_KEY"):
    logging.info("OPENAI_API_KEY detected: %s***", (os.getenv("OPENAI_API_KEY") or "")[:7])
else:
    logging.warning("OPENAI_API_KEY not set")

app = Flask(__name__)
CORS(app)


@app.get("/")
def index():
    # Return a minimal HTML page with a simple chat UI.
    html = r"""
    <!doctype html>
    <html lang="en">
    <head>
      <meta charset="utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <title>Eugene the AI Sea Cow</title>
      <style>
        :root { color-scheme: light dark; }
        body { font-family: -apple-system, system-ui, Segoe UI, Roboto, Helvetica, Arial, sans-serif; margin: 0; }
        .container { max-width: 900px; width: 100%; margin: 2rem auto; padding: 0 1rem; box-sizing: border-box; }
        .row { display: flex; gap: 8px; margin-top: 10px; align-items: center; }
        input[type="text"] { flex: 1; height: 40px; padding: 0 10px; font-size: 16px; box-sizing: border-box; }
        button { padding: 0.6rem 1rem; font-size: 1rem; }
        .checkbox-wrapper { display: flex; align-items: center; gap: 6px; white-space: nowrap; }
        .checkbox-wrapper input[type="checkbox"] { width: 18px; height: 18px; cursor: pointer; }
        .checkbox-wrapper label { font-size: 0.9rem; cursor: pointer; user-select: none; }
        .log { margin-top: 16px; display: flex; flex-direction: column; gap: 12px; }
        .msg { max-width: 80%; padding: 10px 12px; border-radius: 12px; white-space: pre-wrap; word-break: break-word; overflow-wrap: anywhere; }
        .user { align-self: flex-end; background: #0b5cff; color: white; }
        .assistant { align-self: flex-start; background: #f6f8fa; }
        /* Add extra vertical space when switching between user and assistant turns */
        .msg.user + .msg.assistant { margin-top: 22px; }
        .msg.assistant + .msg.user { margin-top: 22px; }
        .status { margin-top: 10px; font-style: italic; opacity: 0.8; }
        @media (max-width: 1024px) { .container { margin: 1rem auto; } }
        h1,h2,h3 { margin: 0.25rem 0; }
        p { margin: 0.25rem 0; }
        ul,ol { margin: 0.25rem 1.25rem; }
        code { background: #f0f2f4; padding: 0 4px; border-radius: 4px; }
      </style>
    </head>
    <body>
      <div class="container">
        <h1>Eugene the AI Sea Cow</h1>
        <div id="log" class="log"></div>
        <div class="row">
          <input id="prompt" type="text" placeholder="Ask me anything, you silly human." />
          <div class="checkbox-wrapper">
            <input type="checkbox" id="govOnly" />
            <label for="govOnly">.gov only</label>
          </div>
          <button id="btn" type="button">Submit</button>
        </div>
        <div id="status" class="status" aria-live="polite"></div>
      </div>
      <script>
        const btn = document.getElementById('btn');
        const promptEl = document.getElementById('prompt');
        const logEl = document.getElementById('log');
        const statusEl = document.getElementById('status');
        const govOnlyCheckbox = document.getElementById('govOnly');
        const messages = [
          { role: 'system', content: 'You are a concise assistant that writes clear answers.' }
        ];

        function render() {
          logEl.innerHTML = '';
          for (const m of messages) {
            if (m.role === 'system') continue;
            const div = document.createElement('div');
            div.className = 'msg ' + (m.role === 'user' ? 'user' : 'assistant');
            if (m.role === 'assistant') {
              // Convert markdown to HTML
              div.innerHTML = renderMarkdown(m.content);
            } else {
              // Remove the .gov filter instruction from display
              let displayContent = m.content;
              displayContent = displayContent.replace(/\s*\(Only cite sources from \.gov domains\)\s*$/, '');
              div.textContent = displayContent;
            }
            logEl.appendChild(div);
          }
          logEl.scrollTop = logEl.scrollHeight;
        }

        function renderMarkdown(text) {
          let html = text;
          
          // Escape HTML first
          html = html.replace(/&/g, '&amp;')
                     .replace(/</g, '&lt;')
                     .replace(/>/g, '&gt;');
          
          // Bold **text**
          html = html.replace(/\*\*([^\*]+)\*\*/g, '<strong>$1</strong>');
          
          // Italic *text* (but not if it's part of **)
          html = html.replace(/(?<!\*)\*([^\*]+)\*(?!\*)/g, '<em>$1</em>');
          
          // Links [text](url)
          html = html.replace(/\[([^\]]+)\]\((https?:\/\/[^\)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
          
          // Inline code `code`
          html = html.replace(/`([^`]+)`/g, '<code>$1</code>');
          
          // Headings
          html = html.replace(/^### (.+)$/gm, '<h3>$1</h3>');
          html = html.replace(/^## (.+)$/gm, '<h2>$1</h2>');
          html = html.replace(/^# (.+)$/gm, '<h1>$1</h1>');
          
          // Line breaks
          html = html.replace(/\n/g, '<br>');
          
          return html;
        }

        async function send() {
          const content = promptEl.value.trim() || 'Say hello.';
          const govOnly = govOnlyCheckbox.checked;
          
          // Add .gov filter instruction to user message if checkbox is checked
          let userContent = content;
          if (govOnly) {
            userContent = content + ' (Only cite sources from .gov domains)';
          }
          
          messages.push({ role: 'user', content: userContent });
          promptEl.value = '';
          render();

          try {
            // show loading state
            statusEl.textContent = 'Looking for your answers…';
            btn.disabled = true; promptEl.disabled = true;
            const res = await fetch('/api/chat?web=1', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ messages })
            });
            const data = await res.json();
            if (data && data.text) {
              messages.push({ role: 'assistant', content: data.text });
            } else if (data && data.error) {
              messages.push({ role: 'assistant', content: 'Error: ' + data.error });
            } else {
              messages.push({ role: 'assistant', content: '(no response)' });
            }
          } catch (e) {
            messages.push({ role: 'assistant', content: 'Error: ' + e });
          }
          render();
          // clear loading state
          statusEl.textContent = '';
          btn.disabled = false; promptEl.disabled = false; promptEl.focus();
        }

        btn.addEventListener('click', send);
        promptEl.addEventListener('keydown', (e) => {
          if (e.key === 'Enter') {
            e.preventDefault();
            send();
          }
        });
        render();
      </script>
    </body>
    </html>
    """
    return render_template_string(html)


@app.get("/api/haiku")
def api_haiku():
    # Read the user's input from the query string (or use a friendly default)
    user_input = request.args.get("input") or "Ask me anything, you silly human."
    try:
        if not os.getenv("OPENAI_API_KEY"):
            return jsonify({"error": "OPENAI_API_KEY not set"}), 500
        # Create a client using your API key
        client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        # Use a fixed model; avoid env-based model selection
        requested_model = "gpt-4o-mini"
        def generate(model_name: str) -> str:
            chat = client.chat.completions.create(
                model=model_name,
                messages=[
                    {"role": "system", "content": "You are a concise assistant that writes clear answers."},
                    {"role": "user", "content": user_input},
                ],
                temperature=0.7,
            )
            return (chat.choices[0].message.content or "").strip()

        try:
            text = generate(requested_model)
            return jsonify({"text": text})
        except Exception as primary_error:
            logging.warning("Primary model '%s' failed: %s", requested_model, primary_error)
            fallback_model = "gpt-4o-mini"
            if requested_model != fallback_model:
                try:
                    text = generate(fallback_model)
                    return jsonify({"text": text})
                except Exception:
                    pass
            raise primary_error
    except Exception as e:
        # Any error here returns JSON `{error: ...}` and a 500 status
        logging.exception("/api/haiku error")
        return jsonify({"error": str(e)}), 500


@app.post("/api/chat")
def api_chat():
    """
    Multi-turn chat endpoint.
    Expects JSON: { "messages": [{"role":"user|assistant|system","content":"..."}, ...] }
    Returns: { "text": "assistant reply" }
    """
    try:
        if not os.getenv("OPENAI_API_KEY"):
            return jsonify({"error": "OPENAI_API_KEY not set"}), 500

        data = request.get_json(silent=True) or {}
        messages = data.get("messages")
        if not isinstance(messages, list) or not messages:
            return jsonify({"error": "messages[] required"}), 400

        # Create a client using your API key
        client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

        # Use a fixed model (no env-based model selection)
        requested_model = "gpt-4o-mini"

        # Enable web only when explicitly requested via query (?web=1)
        use_web = request.args.get("web") == "1"
        if use_web:
            try:
                # Use Responses API with web_search and a fixed, known-good model
                web_model = "gpt-4o-mini"
                # Use the most recent user message as input text
                user_text = None
                for m in reversed(messages):
                    if isinstance(m, dict) and m.get("role") == "user":
                        user_text = m.get("content")
                        break
                if not user_text:
                    user_text = "Provide the latest answer with a source link."
                resp = client.responses.create(
                    model=web_model,
                    input=user_text,
                    tools=[{"type": "web_search"}],
                    tool_choice="auto",
                    store=False,
                )
                text = (resp.output_text or "").strip()
                if text:
                    return jsonify({"text": text, "web": True, "tool": "web_search"})
            except Exception as web_err:
                logging.warning("Web search failed, falling back to chat.completions: %s", web_err)

        def try_model(model_name: str, with_temperature: bool = False) -> str:
            kwargs = {"model": model_name, "messages": messages}
            if with_temperature:
                kwargs["temperature"] = 0.7
            chat = client.chat.completions.create(**kwargs)
            return (chat.choices[0].message.content or "").strip()

        try:
            text = try_model(requested_model, with_temperature=False)
            return jsonify({"text": text})
        except Exception as primary_error:
            logging.warning("Primary model '%s' failed: %s", requested_model, primary_error)
            fallback_model = "gpt-4o-mini"
            if requested_model != fallback_model:
                try:
                    text = try_model(fallback_model, with_temperature=True)
                    return jsonify({"text": text})
                except Exception:
                    pass
            raise primary_error
    except Exception as e:
        logging.exception("/api/chat error")
        return jsonify({"error": str(e)}), 500


STATE_ABBR_TO_FIPS = {
    "AL": "01", "AK": "02", "AZ": "04", "AR": "05", "CA": "06", "CO": "08",
    "CT": "09", "DE": "10", "DC": "11", "FL": "12", "GA": "13", "HI": "15",
    "ID": "16", "IL": "17", "IN": "18", "IA": "19", "KS": "20", "KY": "21",
    "LA": "22", "ME": "23", "MD": "24", "MA": "25", "MI": "26", "MN": "27",
    "MS": "28", "MO": "29", "MT": "30", "NE": "31", "NV": "32", "NH": "33",
    "NJ": "34", "NM": "35", "NY": "36", "NC": "37", "ND": "38", "OH": "39",
    "OK": "40", "OR": "41", "PA": "42", "RI": "44", "SC": "45", "SD": "46",
    "TN": "47", "TX": "48", "UT": "49", "VT": "50", "VA": "51", "WA": "53",
    "WV": "54", "WI": "55", "WY": "56",
}

STATE_ABBR_TO_NAME = {
    "AL": "Alabama", "AK": "Alaska", "AZ": "Arizona", "AR": "Arkansas", "CA": "California",
    "CO": "Colorado", "CT": "Connecticut", "DE": "Delaware", "DC": "District of Columbia",
    "FL": "Florida", "GA": "Georgia", "HI": "Hawaii", "ID": "Idaho", "IL": "Illinois",
    "IN": "Indiana", "IA": "Iowa", "KS": "Kansas", "KY": "Kentucky", "LA": "Louisiana",
    "ME": "Maine", "MD": "Maryland", "MA": "Massachusetts", "MI": "Michigan",
    "MN": "Minnesota", "MS": "Mississippi", "MO": "Missouri", "MT": "Montana",
    "NE": "Nebraska", "NV": "Nevada", "NH": "New Hampshire", "NJ": "New Jersey",
    "NM": "New Mexico", "NY": "New York", "NC": "North Carolina", "ND": "North Dakota",
    "OH": "Ohio", "OK": "Oklahoma", "OR": "Oregon", "PA": "Pennsylvania", "RI": "Rhode Island",
    "SC": "South Carolina", "SD": "South Dakota", "TN": "Tennessee", "TX": "Texas",
    "UT": "Utah", "VT": "Vermont", "VA": "Virginia", "WA": "Washington",
    "WV": "West Virginia", "WI": "Wisconsin", "WY": "Wyoming",
}


@app.get("/api/census/median_income")
def api_census_mhi():
    """
    Get median household income for a US city using the Census ACS API.

    Query params:
    - city: e.g., Savannah
    - state: e.g., GA
    - year: 2023 (default)
    - series: acs1 or acs5 (default acs1)
    """
    city = (request.args.get("city") or "").strip()
    state = (request.args.get("state") or "").strip().upper()
    year = (request.args.get("year") or "2023").strip()
    series = (request.args.get("series") or "acs1").strip().lower()

    if not city or not state:
        return jsonify({"error": "city and state are required, e.g. city=Savannah&state=GA"}), 400
    if state not in STATE_ABBR_TO_FIPS:
        return jsonify({"error": f"unknown state: {state}"}), 400
    if series not in ("acs1", "acs5"):
        return jsonify({"error": "series must be 'acs1' or 'acs5'"}), 400

    dataset = f"acs/{series}"
    state_fips = STATE_ABBR_TO_FIPS[state]
    state_name = STATE_ABBR_TO_NAME.get(state, state)
    target_name = f"{city} city, {state_name}"

    url = f"https://api.census.gov/data/{year}/{dataset}?get=NAME,B19013_001E&for=place:*&in=state:{state_fips}"

    try:
        with httpx.Client(timeout=20) as client:
            r = client.get(url)
            r.raise_for_status()
            data = r.json()
    except Exception as e:
        logging.exception("census api error")
        return jsonify({"error": str(e), "source_url": url}), 502

    try:
        headers = data[0]
        rows = data[1:]
        name_idx = headers.index("NAME")
        value_idx = headers.index("B19013_001E")
        match = None
        for row in rows:
            name = row[name_idx]
            if name.lower() == target_name.lower():
                match = row
                break
        if not match:
            # fallback: loose contains match
            for row in rows:
                name = row[name_idx]
                if city.lower() in name.lower() and state_name.lower() in name.lower():
                    match = row
                    break
        if not match:
            return jsonify({"error": f"could not find '{city}, {state}' in Census places for {state_name}" , "source_url": url}), 404

        value = match[value_idx]
        try:
            value_num = int(value)
        except Exception:
            value_num = None

        return jsonify({
            "city": city,
            "state": state,
            "year": year,
            "series": series,
            "name": match[name_idx],
            "median_household_income": value_num if value_num is not None else value,
            "source_url": url,
        })
    except Exception as e:
        logging.exception("census parse error")
        return jsonify({"error": str(e), "source_url": url}), 500

if __name__ == "__main__":
    # Allow overriding the port via `PORT` env var (default 5000)
    port = int(os.getenv("PORT", "5000"))
    # `FLASK_DEBUG=1` enables auto-reload + debugger (local dev only)
    debug = os.getenv("FLASK_DEBUG", "0") == "1"
    app.run(host="0.0.0.0", port=port, debug=debug)


