"""
Flask app: Eugene the AI Sea Cow chat interface.

Endpoints:
- GET  /           → Chat UI with web search capability
- POST /api/chat   → Multi-turn chat API with optional web search (?web=1)

Environment variables:
- OPENAI_API_KEY (required): your OpenAI API key
- PORT (optional): server port (default 5000)
- FLASK_DEBUG (optional): set to "1" for auto-reload and debug mode
"""

from dotenv import load_dotenv
from flask import Flask, jsonify, render_template_string, request
from openai import OpenAI
from flask_cors import CORS
import logging
import os

from pathlib import Path
# Load `.env` from the app directory so starting the app from any cwd still works
dotenv_path = Path(__file__).resolve().parent / ".env"
load_dotenv(dotenv_path=dotenv_path, override=True)
logging.basicConfig(level=logging.INFO)
if os.getenv("OPENAI_API_KEY"):
    logging.info("OPENAI_API_KEY detected: %s***", (os.getenv("OPENAI_API_KEY") or "")[:7])
else:
    logging.warning("OPENAI_API_KEY not set")

app = Flask(__name__)
CORS(app)


@app.get("/")
def index():
    # Return a minimal HTML page with a simple chat UI.
    html = r"""
    <!doctype html>
    <html lang="en">
    <head>
      <meta charset="utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <title>Eugene the AI Sea Cow</title>
      <link rel="stylesheet" href="/static/css/pico.min.css" />
      <link rel="stylesheet" href="/static/css/custom.css" />
    </head>
    <body>
      <div class="container">
        <h1>Eugene the AI Sea Cow</h1>
        <div id="log" class="log"></div>
        <div class="row">
          <input id="prompt" type="text" placeholder="Ask me anything, you silly human." />
          <div class="checkbox-wrapper">
            <input type="checkbox" id="govOnly" />
            <label for="govOnly">.gov only</label>
          </div>
          <button id="btn" type="button">Submit</button>
        </div>
        <div id="status" class="status" aria-live="polite"></div>
      </div>
      <script>
        const btn = document.getElementById('btn');
        const promptEl = document.getElementById('prompt');
        const logEl = document.getElementById('log');
        const statusEl = document.getElementById('status');
        const govOnlyCheckbox = document.getElementById('govOnly');
        const messages = [
          { role: 'system', content: 'You are a concise assistant that writes clear answers.' }
        ];

        function render() {
          logEl.innerHTML = '';
          for (const m of messages) {
            if (m.role === 'system') continue;
            const div = document.createElement('div');
            div.className = 'msg ' + (m.role === 'user' ? 'user' : 'assistant');
            if (m.role === 'assistant') {
              // Convert markdown to HTML
              div.innerHTML = renderMarkdown(m.content);
            } else {
              // Remove the .gov filter instruction from display
              let displayContent = m.content;
              displayContent = displayContent.replace(/\s*\(Only cite sources from \.gov domains\)\s*$/, '');
              div.textContent = displayContent;
            }
            logEl.appendChild(div);
          }
          logEl.scrollTop = logEl.scrollHeight;
        }

        function renderMarkdown(text) {
          let html = text;
          
          // Escape HTML first
          html = html.replace(/&/g, '&amp;')
                     .replace(/</g, '&lt;')
                     .replace(/>/g, '&gt;');
          
          // Bold **text**
          html = html.replace(/\*\*([^\*]+)\*\*/g, '<strong>$1</strong>');
          
          // Italic *text* (but not if it's part of **)
          html = html.replace(/(?<!\*)\*([^\*]+)\*(?!\*)/g, '<em>$1</em>');
          
          // Links [text](url)
          html = html.replace(/\[([^\]]+)\]\((https?:\/\/[^\)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
          
          // Inline code `code`
          html = html.replace(/`([^`]+)`/g, '<code>$1</code>');
          
          // Headings
          html = html.replace(/^### (.+)$/gm, '<h3>$1</h3>');
          html = html.replace(/^## (.+)$/gm, '<h2>$1</h2>');
          html = html.replace(/^# (.+)$/gm, '<h1>$1</h1>');
          
          // Line breaks
          html = html.replace(/\n/g, '<br>');
          
          return html;
        }

        async function send() {
          const content = promptEl.value.trim() || 'Say hello.';
          const govOnly = govOnlyCheckbox.checked;
          
          // Add .gov filter instruction to user message if checkbox is checked
          let userContent = content;
          if (govOnly) {
            userContent = content + ' (Only cite sources from .gov domains)';
          }
          
          messages.push({ role: 'user', content: userContent });
          promptEl.value = '';
          render();

          try {
            // show loading state
            statusEl.textContent = 'Looking for your answers…';
            btn.disabled = true; promptEl.disabled = true;
            const res = await fetch('/api/chat?web=1', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ messages })
            });
            const data = await res.json();
            if (data && data.text) {
              messages.push({ role: 'assistant', content: data.text });
            } else if (data && data.error) {
              messages.push({ role: 'assistant', content: 'Error: ' + data.error });
            } else {
              messages.push({ role: 'assistant', content: '(no response)' });
            }
          } catch (e) {
            messages.push({ role: 'assistant', content: 'Error: ' + e });
          }
          render();
          // clear loading state
          statusEl.textContent = '';
          btn.disabled = false; promptEl.disabled = false; promptEl.focus();
        }

        btn.addEventListener('click', send);
        promptEl.addEventListener('keydown', (e) => {
          if (e.key === 'Enter') {
            e.preventDefault();
            send();
          }
        });
        render();
      </script>
    </body>
    </html>
    """
    return render_template_string(html)


@app.post("/api/chat")
def api_chat():
    """
    Multi-turn chat endpoint.
    Expects JSON: { "messages": [{"role":"user|assistant|system","content":"..."}, ...] }
    Returns: { "text": "assistant reply" }
    """
    try:
        if not os.getenv("OPENAI_API_KEY"):
            return jsonify({"error": "OPENAI_API_KEY not set"}), 500

        data = request.get_json(silent=True) or {}
        messages = data.get("messages")
        if not isinstance(messages, list) or not messages:
            return jsonify({"error": "messages[] required"}), 400

        # Create OpenAI client
        client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        model = "gpt-4o-mini"

        # Enable web search when requested via query parameter
        use_web = request.args.get("web") == "1"
        if use_web:
            try:
                # Build conversation context from all messages
                conversation_parts = [
                    f"{m.get('role', '').capitalize()}: {m.get('content', '')}"
                    for m in messages
                    if isinstance(m, dict) and m.get("role") in ("system", "user", "assistant")
                ]
                full_context = "\n\n".join(conversation_parts)
                
                # Use Responses API with web_search tool
                resp = client.responses.create(
                    model=model,
                    input=full_context,
                    tools=[{"type": "web_search"}],
                    tool_choice="auto",
                    store=False,
                )
                text = (resp.output_text or "").strip()
                if text:
                    return jsonify({"text": text, "web": True})
            except Exception as web_err:
                logging.warning("Web search failed, falling back to chat.completions: %s", web_err)

        # Standard chat completion (no web search)
        chat = client.chat.completions.create(model=model, messages=messages)
        text = (chat.choices[0].message.content or "").strip()
        return jsonify({"text": text})
    except Exception as e:
        logging.exception("/api/chat error")
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    # Allow overriding the port via `PORT` env var (default 5000)
    port = int(os.getenv("PORT", "5000"))
    # `FLASK_DEBUG=1` enables auto-reload + debugger (local dev only)
    debug = os.getenv("FLASK_DEBUG", "0") == "1"
    app.run(host="0.0.0.0", port=port, debug=debug)


